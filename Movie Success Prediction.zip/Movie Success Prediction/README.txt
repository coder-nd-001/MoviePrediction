1. pip install pandas numpy scikit-learn streamlit
2. python training.py
3. streamlit run app.py
